import sqlite3
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.core.window import Window

DB_PATH = "/storage/emulated/0/wildberries/db/handheld.db"

class MainApp(App):
    def execute_query(self, query):
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.executescript(query)
            conn.commit()
            conn.close()
            self.result_label.text = "Успешно выполнено"
        except Exception as e:
            self.result_label.text = f"Ошибка: {e}"

    def build(self):
        Window.clearcolor = (1, 1, 1, 1)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        btn_close_wave = Button(text="Закрыть сборочный лист", size_hint_y=None, height=60)
        btn_close_wave.bind(on_press=lambda x: self.execute_query(
            "UPDATE WaveDetail SET strike_place_cod = null;"
            "UPDATE WaveDetail SET terminate_dt = DATETIME('now');"
        ))

        btn_swap_places = Button(text="Поменять места товаров", size_hint_y=None, height=60)
        btn_swap_places.bind(on_press=lambda x: self.execute_query(
            "UPDATE WaveDetail SET asm_order = 500 WHERE subject_name = 'Товар';"
        ))

        btn_change_sticker = Button(text="Поменять стикер на перепике", size_hint_y=None, height=60)
        btn_change_sticker.bind(on_press=lambda x: self.execute_query(
            "UPDATE WaveDetail SET barcode_to_rescan = '*BeSv1Qok';"
        ))

        self.result_label = Label(text="", size_hint_y=None, height=40, color=(0, 0, 0, 1))

        layout.add_widget(btn_close_wave)
        layout.add_widget(btn_swap_places)
        layout.add_widget(btn_change_sticker)
        layout.add_widget(self.result_label)

        return layout

if __name__ == "__main__":
    MainApp().run()
